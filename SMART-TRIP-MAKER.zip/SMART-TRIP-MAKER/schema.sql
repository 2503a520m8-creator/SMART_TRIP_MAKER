CREATE DATABASE IF NOT EXISTS smart_trip_maker;
USE smart_trip_maker;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE destinations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    image_url VARCHAR(255),
    base_cost DECIMAL(10,2) NOT NULL
);

CREATE TABLE hotels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    destination_id INT,
    name VARCHAR(100) NOT NULL,
    price_per_night DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (destination_id) REFERENCES destinations(id)
);

CREATE TABLE transport (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(50) NOT NULL,
    price_per_person DECIMAL(10,2) NOT NULL
);

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    destination_id INT,
    hotel_id INT,
    transport_id INT,
    travelers INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    total_cost DECIMAL(10,2) NOT NULL,
    status ENUM('Pending', 'Confirmed', 'Cancelled') DEFAULT 'Confirmed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (destination_id) REFERENCES destinations(id),
    FOREIGN KEY (hotel_id) REFERENCES hotels(id),
    FOREIGN KEY (transport_id) REFERENCES transport(id)
);

-- Insert dummy data for BTech Demonstration
INSERT INTO destinations (name, description, image_url, base_cost) VALUES 
('Goa', 'Beautiful beaches and nightlife', 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?w=500', 5000),
('Manali', 'Snow-capped mountains and valleys', 'https://images.unsplash.com/photo-1626621341517-bbf3d9990a23?w=500', 7000),
('Kerala', 'Gods own country with serene backwaters', 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?w=500', 6000);

INSERT INTO hotels (destination_id, name, price_per_night) VALUES 
(1, 'Taj Exotica Resort', 8000), (1, 'Goa Beach House', 3000),
(2, 'Snow Valley Resorts', 4500), (2, 'Himalayan Retreat', 2500),
(3, 'Kumarakom Lake Resort', 9000), (3, 'Backwater Homestay', 2000);

INSERT INTO transport (type, price_per_person) VALUES 
('Flight', 5500), ('Train (AC)', 1500), ('Volvo Bus', 1200), ('Self-Drive Car', 3000);