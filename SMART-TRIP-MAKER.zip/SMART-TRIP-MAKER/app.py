from flask import Flask, render_template, request, redirect, url_for, session, flash
import pymysql
from werkzeug.security import generate_password_hash, check_password_hash
from config import Config

app = Flask(__name__)
app.config.from_object(Config)

def get_db_connection():
    return pymysql.connect(
        host=app.config['MYSQL_HOST'],
        user=app.config['MYSQL_USER'],
        password=app.config['MYSQL_PASSWORD'],
        db=app.config['MYSQL_DB'],
        cursorclass=pymysql.cursors.DictCursor
    )

@app.route('/')
def index():
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM destinations LIMIT 3")
        destinations = cursor.fetchall()
    conn.close()
    return render_template('index.html', destinations=destinations)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        
        conn = get_db_connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute("INSERT INTO users (name, email, password) VALUES (%s, %s, %s)", (name, email, password))
            conn.commit()
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            flash('Email already exists.', 'danger')
        finally:
            conn.close()
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
            user = cursor.fetchone()
        conn.close()
        
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['name'] = user['name']
            session['role'] = user['role']
            return redirect(url_for('index'))
        else:
            flash('Invalid email or password', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/planner', methods=['GET', 'POST'])
def planner():
    if 'user_id' not in session:
        flash('Please log in to plan a trip.', 'warning')
        return redirect(url_for('login'))
        
    conn = get_db_connection()
    if request.method == 'POST':
        dest_id = request.form['destination']
        hotel_id = request.form['hotel']
        trans_id = request.form['transport']
        travelers = int(request.form['travelers'])
        start = request.form['start_date']
        end = request.form['end_date']
        total = float(request.form['total_cost'])
        
        with conn.cursor() as cursor:
            cursor.execute("""
                INSERT INTO bookings (user_id, destination_id, hotel_id, transport_id, travelers, start_date, end_date, total_cost)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (session['user_id'], dest_id, hotel_id, trans_id, travelers, start, end, total))
        conn.commit()
        conn.close()
        flash('Trip booked successfully!', 'success')
        return redirect(url_for('bookings'))

    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM destinations")
        destinations = cursor.fetchall()
        cursor.execute("SELECT * FROM hotels")
        hotels = cursor.fetchall()
        cursor.execute("SELECT * FROM transport")
        transport = cursor.fetchall()
    conn.close()
    
    return render_template('planner.html', destinations=destinations, hotels=hotels, transport=transport)

@app.route('/bookings')
def bookings():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    conn = get_db_connection()
    with conn.cursor() as cursor:
        if session.get('role') == 'admin':
            cursor.execute("""
                SELECT b.*, u.name as user_name, d.name as dest_name, h.name as hotel_name, t.type as trans_type 
                FROM bookings b
                JOIN users u ON b.user_id = u.id
                JOIN destinations d ON b.destination_id = d.id
                JOIN hotels h ON b.hotel_id = h.id
                JOIN transport t ON b.transport_id = t.id
                ORDER BY b.created_at DESC
            """)
        else:
            cursor.execute("""
                SELECT b.*, d.name as dest_name, h.name as hotel_name, t.type as trans_type 
                FROM bookings b
                JOIN destinations d ON b.destination_id = d.id
                JOIN hotels h ON b.hotel_id = h.id
                JOIN transport t ON b.transport_id = t.id
                WHERE b.user_id = %s
                ORDER BY b.created_at DESC
            """, (session['user_id'],))
        bookings = cursor.fetchall()
    conn.close()
    return render_template('bookings.html', bookings=bookings)

if __name__ == '__main__':
    app.run(debug=True)