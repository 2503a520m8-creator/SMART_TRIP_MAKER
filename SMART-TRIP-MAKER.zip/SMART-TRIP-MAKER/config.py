import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'super-secret-btech-key'
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = '' # Change to your MySQL password
    MYSQL_DB = 'smart_trip_maker'